	<header>
			<div class="container">
					<div class="row">
						<div class="col-lg-12 logo-sec">
							<a href="javascript: ;"><img src="{{ asset('frontend/images/logo.png') }}" alt=""></a>
						</div>
				</div>
		</div>
	</header>